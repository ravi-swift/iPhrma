//
//  AboutUsViewController.swift
//  IshwarPharma
//
//  Created by Rp on 26/03/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class AboutUsViewController: UIViewController {

    @IBOutlet weak var lblDetailsFirst: UILabel!
    @IBOutlet weak var lblDetailsSecound: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
//        lblDetailsFirst.frame = CGRect.init(x: 10, y: 15, width: UIScreen.main.bounds.size.width-20, height: 21)
//        lblDetailsFirst.sizeToFit()
//
//        lblDetailsSecound.frame = CGRect.init(x: 10, y: 218, width: UIScreen.main.bounds.size.width-20, height: 21)
//        lblDetailsSecound.sizeToFit()
    }
    
    @IBAction func clickOnBack(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
}
