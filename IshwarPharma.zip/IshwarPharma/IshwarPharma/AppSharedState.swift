//
//  AppSharedState.swift
//  Ishwar Pharma
//
//  Created by Admin on 09/07/1939 Saka.
//  Copyright © 1939 Saka anonimous. All rights reserved.
//

import UIKit
class AppSharedState {
    var Products = [Product]()
    var Downloads = [DownloadDetails]()
    var productsDict = [String: Product]()
    var Orders = [OrderDetail]()
    var OrderHistory = [OrderDetail]()
    var companies = [String]()
    var types = [String]()
    var companiesT = [String]()
    var typesT = [String]()
    var Name = ""
    var Email = ""
    var Number = ""
   
    func getProfileData()
    {
        // Getting
        let defaults = UserDefaults.standard
        if(defaults.string(forKey: "Email") != nil)
        {
            Name = defaults.string(forKey: "Name")!
            Email = defaults.string(forKey: "Email")!
            Number = defaults.string(forKey: "Number")!
            
        }
    }
    func storeProfileData()
    {
        let defaults = UserDefaults.standard
        defaults.set(Name, forKey: "Name")
        defaults.set(Email, forKey: "Email")
        defaults.set(Number, forKey: "Number")
        defaults.synchronize()
    }
    static let sharedInstance = AppSharedState()
}
class OrderDetail{
    var product:Product? = nil
    var orderQty = String()
    var orderCase = String()
    var freeScheme = String()
    var remarks = String()
    var total = 0.0
    var isSelected = true;
    var lut : Int64 = 0
    func updateTotal()
    {
        //        let rate = NSString(string: product!.mrp).doubleValue
        //        let orderQ = NSString(string: orderQty).doubleValue
        // let shipper = NSString(string: product!.qty).doubleValue
        //total = rate * orderQ * shipper
    }
}
class DownloadDetails
{
    var name : String = ""
    var url : String = ""
    init(json: NSDictionary) throws {
        // Extract name
        guard let nameJson = json["name"] as? String else {
            fatalError("name")
            //return nil
        }
        guard let linkJson = json["link"] as? String else {
            fatalError("name")
            //return nil
        }
        
        
        // Initialize properties
        self.name = nameJson
        self.url = linkJson
        
        
    }
}
