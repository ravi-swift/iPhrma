//
//  OrderDetailsItemTableViewCell.swift
//  Ishwar Pharma
//
//  Created by Admin on 10/07/1939 Saka.
//  Copyright © 1939 Saka anonimous. All rights reserved.
//

import UIKit
protocol SwitchChangedDelegate {
    func switchChanged()
}
class OrderDetailsItemTableViewCell: UITableViewCell {

    @IBAction func SpecialRemarks(_ sender: Any) {
    }
    @IBAction func delete_Clicked(_ sender: Any) {
        var index = 0;
        for orderDetails in AppSharedState.sharedInstance.Orders
        {
            if((orderDetails.lut == order.lut) && (((orderDetails.product?.key = (order.product?.key)!) != nil)))
            {
                break;
            }
            index = index + 1
        }
        AppSharedState.sharedInstance.Orders.remove(at: index)
        DataProvider.instance.deleteOrder(order: order)
        UserDefaults.standard.set("\(AppSharedState.sharedInstance.Orders.count)", forKey: "OrderCount")
        UserDefaults.standard.synchronize()
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadCount"), object: nil, userInfo: [:])
        self.delegate?.switchChanged()
    }
    @IBOutlet var ProdutName: UILabel!
    @IBOutlet var OrderQty: UILabel!
    @IBOutlet var SelectedSwitch: UISwitch!
    @IBAction func SwitchChanged(_ sender: Any) {
        order.isSelected = SelectedSwitch.isOn
        self.delegate?.switchChanged()
    }
    var delegate:SwitchChangedDelegate?
    var order: OrderDetail!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }

}
