//
//  HomeViewController.swift
//  Ishwar Pharma
//
//  Created by Rp on 22/03/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UITextFieldDelegate {
    
    @IBOutlet weak var viewTopImg: UIView!
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var collectionViewCompany: UICollectionView!
    @IBOutlet weak var collectionViewCategory: UICollectionView!
    @IBOutlet weak var collectionviewProduct: UICollectionView!
    @IBOutlet weak var collectionViewArrivels: UICollectionView!
    @IBOutlet weak var heightTopProduct: NSLayoutConstraint!
    
    var arrNewArrivals = NSArray()
    var arrTopProducts = NSArray()
    var arrBANNERS = NSArray()
    var arrShopByCompany = NSArray()
    var arrShopByCategory = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        viewTopImg.layer.cornerRadius = 10
        viewTopImg.layer.shadowColor = UIColor.lightGray.cgColor
        viewTopImg.layer.shadowOpacity = 3
        viewTopImg.layer.shadowOffset = CGSize.zero
        viewTopImg.layer.shadowRadius = 3
        
        if GlobalFunction.iSinternetConnection(){
            
            self.getArrivalsTopProducts()
            self.getBANNERSCOMPANYCATEGORY()
        }
        else{
            
            let arrArrivalsTopProducts = DBHandler.getDataFromTable("SELECT * FROM TopProducts")
            
            let predicate = NSPredicate.init(format: "CarouselName=%@ AND IsDeleted=%@", "New Arrivals","0")
            self.arrNewArrivals = arrArrivalsTopProducts!.filtered(using: predicate) as NSArray
            
            let predicateProduct = NSPredicate.init(format: "CarouselName=%@ AND IsDeleted=%@", "Top Products","0")
            self.arrTopProducts = arrArrivalsTopProducts!.filtered(using: predicateProduct) as NSArray
            
            if self.arrTopProducts.count == 0{
                self.heightTopProduct.constant = 0
            }
            
            self.collectionViewArrivels.reloadData()
            self.collectionviewProduct.reloadData()
            
            /////
            
            let arrBANNERSCOMPANYCATEGORY = DBHandler.getDataFromTable("SELECT * FROM TopBanners")
            
            let predicate2 = NSPredicate.init(format: "CarouselName=%@ AND IsDeleted=%@", "BANNERS","0")
            self.arrBANNERS = arrBANNERSCOMPANYCATEGORY!.filtered(using: predicate2) as NSArray
            
            let arrSlideImage = NSMutableArray()
            
            for index in 0..<self.arrBANNERS.count{
                
                let dic = self.arrBANNERS.object(at: index) as! NSDictionary
                
                let slide = JOLImageSlide()
                slide.image = dic.value(forKey: "ImageURL") as? String
                arrSlideImage.add(slide)
                
            }
            
            let imageSlider = JOLImageSlider.init(frame: CGRect.init(x: 0, y: 0, width: (self.viewTopImg.frame.size.width), height:self.viewTopImg.frame.size.height), andSlides: arrSlideImage as! [Any])
            imageSlider?.autoSlide = true
            self.viewTopImg.addSubview(imageSlider!)
            
            let predicateCompany = NSPredicate.init(format: "CarouselName=%@ AND IsDeleted=%@", "SHOP BY COMPANY","0")
            self.arrShopByCompany = arrBANNERSCOMPANYCATEGORY!.filtered(using: predicateCompany) as NSArray
            
            let prdicateCategory = NSPredicate.init(format: "CarouselName=%@ AND IsDeleted=%@", "SHOP BY CATEGORY","0")
            self.arrShopByCategory = arrBANNERSCOMPANYCATEGORY!.filtered(using: prdicateCategory) as NSArray
            
            self.collectionViewCompany.reloadData()
            self.collectionViewCategory.reloadData()
        }
        
        
    }
    
    
    func getArrivalsTopProducts(){
        
        let str = "http://www.onride.co.in/ishwarpharma/productmapping.php"
        
        let url = URL.init(string: str)
        
        let request = NSMutableURLRequest.init(url: url as! URL)
        request.httpMethod = "GET"
        
        let configuartion = URLSessionConfiguration.default
        
        let session = URLSession.init(configuration: configuartion)
        
        let task =  session.dataTask(with: request as URLRequest, completionHandler: {(data,response, error) -> Void in
            
            do{
                
                let arrArrivalsTopProducts = try JSONSerialization.jsonObject(with: data!, options: .mutableLeaves) as! NSArray
                
                print(arrArrivalsTopProducts)
                
                DispatchQueue.main.async {
                    
                    let predicate = NSPredicate.init(format: "CarouselName=%@ AND IsDeleted=%@", "New Arrivals","0")
                    self.arrNewArrivals = arrArrivalsTopProducts.filtered(using: predicate) as NSArray
                    
                    let predicateProduct = NSPredicate.init(format: "CarouselName=%@ AND IsDeleted=%@", "Top Products","0")
                    self.arrTopProducts = arrArrivalsTopProducts.filtered(using: predicateProduct) as NSArray
                    
                    DBHandler.deleteData("DELETE FROM TopProducts")
                    
                    for index in 0..<arrArrivalsTopProducts.count
                    {
                        let dic = arrArrivalsTopProducts.object(at: index) as! NSDictionary
                        
                        let sortOrder = dic.value(forKey: "Carousel Sort Order") as! String
                        let CarouselID = dic.value(forKey: "CarouselID") as! String
                        let CarouselName = dic.value(forKey: "CarouselName") as! String
                        let codeKey = dic.value(forKey: "Code Key") as! String
                        let CreatedAt = dic.value(forKey: "CreatedAt") as! String
                        let ID = dic.value(forKey: "ID") as! String
                        let ImageURL = dic.value(forKey: "ImageURL") as! String
                        let IsDeleted = dic.value(forKey: "IsDeleted") as! String
                        let ItemName = dic.value(forKey: "Item Name") as! String
                        let productSortOrder = dic.value(forKey: "Product Sort Order") as! String
                        
                        let success = DBHandler.addTopProduct(sortOrder, carouselID: CarouselID, carouselName: CarouselName, codeKey: codeKey, createdAt: CreatedAt, id: ID, imageURL: ImageURL, isDeleted: IsDeleted, itemName: ItemName, productsortOrder: productSortOrder, isDeleted: IsDeleted)
                        
                        if success
                        {
                            print("SUCCESS")
                        }
                        else{
                            
                        }
                        
                    }
                    
                    if self.arrTopProducts.count == 0{
                        self.heightTopProduct.constant = 0
                    }
                    
                    self.collectionViewArrivels.reloadData()
                    self.collectionviewProduct.reloadData()
                }
                
            }catch{
                
                print(error)
            }
            
        })
        task.resume()
    }
    
    func getBANNERSCOMPANYCATEGORY(){
        
        let str = "http://www.onride.co.in/ishwarpharma/carousel.php"
        
        let url = URL.init(string: str)
        
        let request = NSMutableURLRequest.init(url: url as! URL)
        request.httpMethod = "GET"
        
        let configuartion = URLSessionConfiguration.default
        
        let session = URLSession.init(configuration: configuartion)
        
        let task =  session.dataTask(with: request as URLRequest, completionHandler: {(data,response, error) -> Void in
            
            do{
                
                let arrBANNERSCOMPANYCATEGORY = try JSONSerialization.jsonObject(with: data!, options: .mutableLeaves) as! NSArray
                
                print(arrBANNERSCOMPANYCATEGORY)
                
                DispatchQueue.main.async {
                    
                    let predicate = NSPredicate.init(format: "CarouselName=%@ AND IsDeleted=%@", "BANNERS","0")
                    self.arrBANNERS = arrBANNERSCOMPANYCATEGORY.filtered(using: predicate) as NSArray
                    
                    let arrSlideImage = NSMutableArray()
                    
                    for index in 0..<self.arrBANNERS.count{
                        
                        let dic = self.arrBANNERS.object(at: index) as! NSDictionary
                        
                        let slide = JOLImageSlide()
                        slide.image = dic.value(forKey: "ImageURL") as? String
                        arrSlideImage.add(slide)
                        
                    }
                    
                    let imageSlider = JOLImageSlider.init(frame: CGRect.init(x: 0, y: 0, width: (self.viewTopImg.frame.size.width), height:self.viewTopImg.frame.size.height), andSlides: arrSlideImage as! [Any])
                    imageSlider?.autoSlide = true
                    self.viewTopImg.addSubview(imageSlider!)
                    
                    let predicateCompany = NSPredicate.init(format: "CarouselName=%@ AND IsDeleted=%@", "SHOP BY COMPANY","0")
                    self.arrShopByCompany = arrBANNERSCOMPANYCATEGORY.filtered(using: predicateCompany) as NSArray
                    
                    let prdicateCategory = NSPredicate.init(format: "CarouselName=%@ AND IsDeleted=%@", "SHOP BY CATEGORY","0")
                    self.arrShopByCategory = arrBANNERSCOMPANYCATEGORY.filtered(using: prdicateCategory) as NSArray
                    
                    DBHandler.deleteData("DELETE FROM TopBanners")
                    
                    for index in 0..<arrBANNERSCOMPANYCATEGORY.count
                    {
                        let dic = arrBANNERSCOMPANYCATEGORY.object(at: index) as! NSDictionary
                        
                        let sortOrder = dic.value(forKey: "Banner Sort Order") as! String
                        let CarouselID = dic.value(forKey: "CarouselID") as! String
                        let CarouselName = dic.value(forKey: "CarouselName") as! String
                        let CreatedAt = dic.value(forKey: "CreatedAt") as! String
                        let ID = dic.value(forKey: "ID") as! String
                        let ImageURL = dic.value(forKey: "ImageURL") as! String
                        let IsDeleted = dic.value(forKey: "IsDeleted") as! String
                        let ItemName = dic.value(forKey: "ItemName") as! String
                        let productSortOrder = dic.value(forKey: "Product Sort Order") as! String
                        
                        let success = DBHandler.addTopBanners(sortOrder, carouselID: CarouselID, carouselName: CarouselName, createdAt: CreatedAt, id: ID, imageURL: ImageURL, isDeleted: IsDeleted, itemName: ItemName, productsortOrder: productSortOrder, isDeleted: IsDeleted)
                        
                        if success
                        {
                            print("SUCCESS")
                        }
                        else{
                            
                        }
                    }
                    
                    self.collectionViewCompany.reloadData()
                    self.collectionViewCategory.reloadData()
                }
                
            }catch{
                
                print(error)
            }
            
        })
        task.resume()
    }
    
    
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if collectionView == collectionViewCompany{
            
            return arrShopByCompany.count
            
        }else if collectionView == collectionViewCategory{
            
            return arrShopByCategory.count
            
        }else if collectionView == collectionviewProduct{
            
            return arrTopProducts.count
            
        }else{
            
            return arrNewArrivals.count
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView == collectionViewCompany{
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
            let view = cell.contentView.viewWithTag(1002)as! UIView
            view.layer.cornerRadius = 5
            //     cell.layer.masksToBounds = true
            view.layer.shadowColor = UIColor.black.cgColor
            view.layer.shadowOpacity = 1
            view.layer.shadowOffset = CGSize.zero
            view.layer.shadowRadius = 0.5
            let imgView = cell.contentView.viewWithTag(1003)as! UIImageView
            let lblProductName = cell.contentView.viewWithTag(1004)as! UILabel
            
            let dictCompany = self.arrShopByCompany.object(at: indexPath.item) as! NSDictionary
            lblProductName.text = dictCompany.value(forKey: "ItemName") as? String
            
            var strUrl = dictCompany.value(forKey: "ImageURL") as! String
            
            strUrl = strUrl.addingPercentEncoding(withAllowedCharacters: CharacterSet .urlQueryAllowed)!
            
            imgView.sd_setImage(with: URL.init(string: strUrl), placeholderImage: nil, options: .continueInBackground, completed: nil)
            
            return cell
            
        }else if collectionView == collectionViewCategory{
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
            let view = cell.contentView.viewWithTag(1002)as! UIView
            view.layer.cornerRadius = 5
            //     cell.layer.masksToBounds = true
            view.layer.shadowColor = UIColor.black.cgColor
            view.layer.shadowOpacity = 1
            view.layer.shadowOffset = CGSize.zero
            view.layer.shadowRadius = 0.5
            let imgView = cell.contentView.viewWithTag(1003)as! UIImageView
            let lblProductName = cell.contentView.viewWithTag(1004)as! UILabel
            
            let dictCategory = self.arrShopByCategory.object(at: indexPath.item) as! NSDictionary
            
            lblProductName.text = dictCategory.value(forKey: "ItemName") as? String
            
            var strUrl = dictCategory.value(forKey: "ImageURL") as! String
            
            strUrl = strUrl.addingPercentEncoding(withAllowedCharacters: CharacterSet .urlQueryAllowed)!
            
            imgView.sd_setImage(with: URL.init(string: strUrl), placeholderImage: nil, options: .continueInBackground, completed: nil)
            
            return cell
            
        }else if collectionView == collectionviewProduct{
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
            
            let imgView = cell.contentView.viewWithTag(1003)as! UIImageView
            imgView.layer.cornerRadius = imgView.frame.size.height/2
            imgView.layer.borderColor = UIColor.black.cgColor
            imgView.layer.borderWidth = 1
            imgView.layer.masksToBounds = true
            let lblProductName = cell.contentView.viewWithTag(1004)as! UILabel
            
            let dicTopProducts = self.arrTopProducts.object(at: indexPath.item) as! NSDictionary
            
            lblProductName.text = dicTopProducts.value(forKey: "Item Name") as? String
            
            var strUrl = dicTopProducts.value(forKey: "ImageURL") as! String
            
            strUrl = strUrl.addingPercentEncoding(withAllowedCharacters: CharacterSet .urlQueryAllowed)!
            
            imgView.sd_setImage(with: URL.init(string: strUrl), placeholderImage: nil, options: .continueInBackground, completed: nil)
            
            return cell
            
        }else{
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
            
            let imgView = cell.contentView.viewWithTag(1003)as! UIImageView
            imgView.layer.cornerRadius = imgView.frame.size.height/2
            imgView.layer.borderColor = UIColor.black.cgColor
            imgView.layer.borderWidth = 1
            imgView.layer.masksToBounds = true
            let lblProductName = cell.contentView.viewWithTag(1004)as! UILabel
            
            let dictCompany = self.arrNewArrivals.object(at: indexPath.item) as! NSDictionary
            lblProductName.text = dictCompany.value(forKey: "Item Name") as? String
            
            var strUrl = dictCompany.value(forKey: "ImageURL") as! String
            
            strUrl = strUrl.addingPercentEncoding(withAllowedCharacters: CharacterSet .urlQueryAllowed)!
            
            imgView.sd_setImage(with: URL.init(string: strUrl), placeholderImage: nil, options: .continueInBackground, completed: nil)
            
            
            return cell
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if collectionView == self.collectionViewCompany
        {
            let pageMenu = self.parent as! CAPSPageMenu
            let productVC = pageMenu.controllerArray[1] as! ProductsViewController
            productVC.str = (self.arrShopByCompany.object(at: indexPath.row) as! NSDictionary).value(forKey: "ItemName") as! String
            productVC.strType = "company"
            pageMenu.move(toPage: 1)
        }
        else if collectionView == self.collectionViewCategory
        {
            let pageMenu = self.parent as! CAPSPageMenu
            let productVC = pageMenu.controllerArray[1] as! ProductsViewController
            productVC.str = (self.arrShopByCategory.object(at: indexPath.row) as! NSDictionary).value(forKey: "ItemName") as! String
            productVC.strType = "type"
            pageMenu.move(toPage: 1)
        }
        else if collectionView == self.collectionviewProduct
        {
            
            let addToCartVC = self.storyboard?.instantiateViewController(withIdentifier: "AddToCartViewController") as! AddToCartViewController
            
            addToCartVC.modalTransitionStyle = .crossDissolve
            
            if (UIDevice.current.systemVersion as NSString).floatValue >= 8.0
            {
                addToCartVC.modalPresentationStyle = .overCurrentContext
                addToCartVC.definesPresentationContext = true
            }
            else{
                
                addToCartVC.modalPresentationStyle = .currentContext
            }
            
            let selectedIndex = indexPath
            let globalVar = selectedIndex.row
            print("tableView prepareForSegue: " + String(globalVar))
            let dic = self.arrTopProducts[globalVar] as! NSDictionary
            
            var filteredArray : [Product] = []
            
            if AppSharedState.sharedInstance.Products.count > 0{
                
                filteredArray = AppSharedState.sharedInstance.Products.filter( { (product: Product) -> Bool in
                    
                   return product.key == (dic.value(forKey: "Code Key") as! String).uppercased()
                })
            }
            else{
                let pageMenu = self.parent as! CAPSPageMenu
                let productVC = pageMenu.controllerArray[1] as! ProductsViewController
                
                filteredArray = productVC.products.filter( { (product: Product) -> Bool in
                    
                    return product.key == (dic.value(forKey: "Code Key") as! String).uppercased()
                })
            }
            
            if filteredArray.count > 0{
                addToCartVC.product = filteredArray[0]
                self.present(addToCartVC, animated: true, completion: nil)
            }
            
        }
        else
        {
            
            
            let addToCartVC = self.storyboard?.instantiateViewController(withIdentifier: "AddToCartViewController") as! AddToCartViewController
            
            addToCartVC.modalTransitionStyle = .crossDissolve
            
            if (UIDevice.current.systemVersion as NSString).floatValue >= 8.0
            {
                addToCartVC.modalPresentationStyle = .overCurrentContext
                addToCartVC.definesPresentationContext = true
            }
            else{
                
                addToCartVC.modalPresentationStyle = .currentContext
            }
            
            let selectedIndex = indexPath
            let globalVar = selectedIndex.row
            print("tableView prepareForSegue: " + String(globalVar))
            let dic = self.arrNewArrivals[globalVar] as! NSDictionary
            
            var filteredArray : [Product] = []
            
            if AppSharedState.sharedInstance.Products.count > 0{
                
                filteredArray = AppSharedState.sharedInstance.Products.filter( { (product: Product) -> Bool in
                    
                    return product.key == (dic.value(forKey: "Code Key") as! String).uppercased()
                })
            }
            else{
                let pageMenu = self.parent as! CAPSPageMenu
                let productVC = pageMenu.controllerArray[1] as! ProductsViewController
                
                filteredArray = productVC.products.filter( { (product: Product) -> Bool in
                    
                    return product.key == (dic.value(forKey: "Code Key") as! String).uppercased()
                })
            }
            
            if filteredArray.count > 0{
                addToCartVC.product = filteredArray[0]
                self.present(addToCartVC, animated: true, completion: nil)
            }
            
            
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if collectionView == collectionViewCompany{
            
            let size = CGSize.init(width: 150, height: 90)
            return size
            
        }else if collectionView == collectionViewCategory{
            
            let size = CGSize.init(width: 150, height: 90)
            return size
            
        }else if collectionView == collectionviewProduct{
            
            let size = CGSize.init(width: 90, height: 120)
            return size
            
        }else{
            
            let size = CGSize.init(width: 90, height: 120)
            return size
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        if collectionView == collectionViewCompany{
            
            return UIEdgeInsets.init(top: 5, left: 2, bottom: 5, right: 2)
            
        }else if collectionView == collectionViewCategory{
            
            return UIEdgeInsets.init(top: 5, left: 2, bottom: 5, right: 2)
            
        }else if collectionView == collectionviewProduct{
            
            return UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
            
        }else{
            
            return UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
        }
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        let pageMenu = self.parent as! CAPSPageMenu
        pageMenu.move(toPage: 1)
        
        return false
    }
    
}
