//
//  SettingViewController.swift
//  Ishwar Pharma
//
//  Created by Rp on 25/03/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class SettingViewController: UIViewController, UIGestureRecognizerDelegate,didFinishOk {
    
    @IBOutlet weak var viewDisplayName: UIView!
    @IBOutlet weak var viewEmail: UIView!
    @IBOutlet weak var viewPhoneNumber: UIView!
    
    @IBOutlet weak var lblDisplayName: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblPhone: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        //        viewDisplayName.tag = 1001
        //        viewEmail.tag = 1002
        //        viewPhoneNumber.tag = 1003
        
        let tapGestureDisplayName = UITapGestureRecognizer.init(target: self, action: #selector(tapOnViewDisplay(gesture:)))
        tapGestureDisplayName.delegate = self
        viewDisplayName.isUserInteractionEnabled = true
        viewDisplayName.addGestureRecognizer(tapGestureDisplayName)
        
        let tapGestureEmail = UITapGestureRecognizer.init(target: self, action: #selector(tapOnViewDisplay(gesture:)))
        tapGestureEmail.delegate = self
        viewEmail.isUserInteractionEnabled = true
        viewEmail.addGestureRecognizer(tapGestureEmail)
        
        let tapGesturePhoneNumber = UITapGestureRecognizer.init(target: self, action: #selector(tapOnViewDisplay(gesture:)))
        tapGesturePhoneNumber.delegate = self
        viewPhoneNumber.isUserInteractionEnabled = true
        viewPhoneNumber.addGestureRecognizer(tapGesturePhoneNumber)
        
        AppSharedState.sharedInstance.getProfileData()

        lblDisplayName.text = AppSharedState.sharedInstance.Name
        lblEmail.text = AppSharedState.sharedInstance.Email
        lblPhone.text = AppSharedState.sharedInstance.Number
    }
  
    func didFinishWithOk() {
        
        AppSharedState.sharedInstance.getProfileData()
        
        lblDisplayName.text = AppSharedState.sharedInstance.Name
        lblEmail.text = AppSharedState.sharedInstance.Email
        lblPhone.text = AppSharedState.sharedInstance.Number
    }
    
    @objc func tapOnViewDisplay(gesture:UITapGestureRecognizer){
        
        var tagNumber = NSInteger()
        
        
        if gesture.view?.tag == 1001{
            
            tagNumber = 0
            
        }else if gesture.view?.tag == 1002{
            
            tagNumber = 1
            
        }else if gesture.view?.tag == 1003{
            
            tagNumber = 2
        }
        
        let settingPopUp = self.storyboard?.instantiateViewController(withIdentifier: "SettingPopUpVC") as! SettingPopUpVC
        
        settingPopUp.modalTransitionStyle = .crossDissolve
        
        if (UIDevice.current.systemVersion as! NSString).floatValue >= 8.0{
            
            settingPopUp.modalPresentationStyle = .overCurrentContext
            settingPopUp.definesPresentationContext = true
            
        }else{
            
            settingPopUp.modalPresentationStyle = .currentContext
        }
        
        settingPopUp.viewStatus = tagNumber
        settingPopUp.delegate = self
        self.present(settingPopUp, animated: true, completion: nil)
    }
    
    
    @IBAction func clickOnBack(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
}
