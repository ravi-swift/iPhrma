//
//  AddToCartViewController.swift
//  Ishwar Pharma
//
//  Created by Rp on 25/03/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class AddToCartViewController: UIViewController,UITextFieldDelegate {
    
    
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var lblProductDescription: UILabel!
    @IBOutlet weak var lblCompanyName: UILabel!
    @IBOutlet weak var lblPack: UILabel!
    @IBOutlet weak var lblType: UILabel!
    @IBOutlet weak var lblRate: UILabel!
    @IBOutlet weak var lblMrp: UILabel!
    @IBOutlet weak var lblScheme: UILabel!
    
    @IBOutlet weak var txtOrderBox: UITextField!
    @IBOutlet weak var txtFreeScheme: UITextField!
    @IBOutlet weak var txtOrderCase: UITextField!
    @IBOutlet weak var txtRemarks: UITextField!
    
    var product:Product? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        
        lblCompanyName.text = product?.company.uppercased()
        lblProductDescription.text = product?.description.uppercased()
        lblProductName.text = product?.name
        lblPack.text = product?.packing
        lblType.text = product?.type.uppercased()
        lblRate.text = "Rs. " + (product?.rate)!
        lblMrp.text = "Rs. " + (product?.mrp)!
        lblScheme.text = product?.scheme == "" ? "N.A" : product?.scheme
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        self.view.endEditing(true)
        return false
    }
    
    
    @IBAction func clickOnBack(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func clickOnAddtoCart(_ sender: Any) {
        
        view.endEditing(true)
        let  detail = OrderDetail()
        detail.product = self.product
        detail.orderQty = "0";
        detail.orderCase = "0";
        detail.freeScheme = "N.A";
        if self.txtOrderCase.text != nil
        {
            detail.orderCase = self.txtOrderCase.text!
        }
        if self.txtOrderBox.text != nil
        {
            detail.orderQty  = self.txtOrderBox.text!
        }
        if self.txtFreeScheme.text != nil
        {
            detail.freeScheme = self.txtFreeScheme.text!
        }
        if(detail.orderQty == "")
        {
            detail.orderQty = "0"
        }
        if(detail.orderCase == "")
        {
            detail.orderCase = "0"
        }
        if (detail.freeScheme == "")
        {
            detail.freeScheme = "N.A"
        }
        if((detail.orderQty == "0") &&  (detail.orderCase == "0"))
        {
            let alert = UIAlertController(title: "Ishwar Pharma", message: "Please enter Order Units or Order cases greater than 0!", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.cancel, handler: nil))
            self.present(alert, animated: true, completion: nil)
            return;
        }
        if((detail.orderQty != "0") &&  (detail.orderCase != "0"))
        {
            let alert = UIAlertController(title: "Ishwar Pharma", message: "Please enter either Order Units or Order cases!", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.cancel, handler: nil))
            self.present(alert, animated: true, completion: nil)
            return;
        }
        
        if self.txtRemarks.text != nil
        {
            detail.remarks = self.txtRemarks.text!
        }
        //detail.updateTotal()
        detail.lut = Int64(NSDate().timeIntervalSince1970)
        AppSharedState.sharedInstance.Orders.append(detail)
        DataProvider.instance.addOrder(order: detail)
        UserDefaults.standard.set("\(AppSharedState.sharedInstance.Orders.count)", forKey: "OrderCount")
        UserDefaults.standard.synchronize()
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadCount"), object: nil, userInfo: [:])
        self.dismiss(animated: true)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
        
    }
    
}
