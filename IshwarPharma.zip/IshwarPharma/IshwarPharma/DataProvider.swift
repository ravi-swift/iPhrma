//
//  DataProvider.swift
//  Ishwar Pharma
//
//  Created by Admin on 13/07/1939 Saka.
//  Copyright © 1939 Saka anonimous. All rights reserved.
//

import UIKit
import SQLite
class DataProvider{
    static let instance = DataProvider()
    private var db: Connection?
    private let products = Table("products")
    private let companies = Table("companies")
    private let types = Table("types")
    private let orders = Table("orders")
    private let name = Expression<String>("name")
    private let desc = Expression<String?>("description")
    private let company = Expression<String>("company")
    private let type = Expression<String>("type")
    private let mrp = Expression<String>("mrp")
    private let rate = Expression<String?>("rate")
    private let orderQty = Expression<String>("units")
    private let orderCases = Expression<String>("cases")
    private let key = Expression<String>("key")
    private let remarks = Expression<String>("remarks")
    //private let shipper = Expression<String?>("shipper")
    private let packing = Expression<String>("packing")
    private let orderStatus = Expression<Int64>("status")
    private let lut = Expression<Int64>("lut")
    private let companySelected = Expression<Bool>("selected")
    private let typeSelected = Expression<Bool>("selected")
    private let scheme = Expression<String>("scheme")
    
    var lutMax:Int64
    private init() {
        
        lutMax = 0;
        
    }
    
    
    func updateCompany(companyStr: String, selectedB:Bool) {
        
        let success = DBHandler.genericQuery("update companies set selected = " + selectedB.asSQL() + " where company = '" + companyStr + "'")
        
        if success{
            print("update company")
        }
        
    }
    
    func updateType(typeStr: String, selectedB:Bool) {
        
        let success = DBHandler.genericQuery("update types set selected = " + selectedB.asSQL() + " where type = '" + typeStr + "'")
        
        if success{
            print("update types")
        }
        
    }
    func removeProducts() {
        
        let success = DBHandler.genericQuery("delete from 'products'")
        
        if success{
            print("remove all products")
        }
        
    }
    func addOrder(order: OrderDetail) {
        
        let suceess = DBHandler.addOrder(order.product?.key, quantity: order.orderQty, orderCases: order.orderCase, remarks: order.remarks, orderStatus: 0, lut: Int(order.lut))
        
        if suceess{
            print("Order Added")
        }
        
    }
    func updateOrder(order: OrderDetail)
    {
        let success = DBHandler.genericQuery("update orders set status = 1 where key = '" + (order.product?.key)! + "' and lut = " + String(order.lut))
        
        if success{
            print("Order Updated")
        }
        
    }
    func deleteOrder(order: OrderDetail)
    {
        
        let success = DBHandler.genericQuery("delete from orders where key = '" + (order.product?.key)! + "' and lut = " + String(order.lut))
        
        if success{
            print("Order Deleted")
        }
        
    }
    
    func getProducts() -> [Product] {
        
        var products = [Product]()
        
        let arrCompanies = DBHandler.getDataFromTable("SELECT * FROM companies")
        
        do {
            for companyItem in arrCompanies! {
                
                let dicCompanies = companyItem as! NSDictionary
                
                let company = dicCompanies.value(forKey: "company") as! String
                let selected = (dicCompanies.value(forKey: "selected") as! NSString).integerValue
                
                
                do {
                    if(selected == 1 && !AppSharedState.sharedInstance.companies.contains(company))
                    {
                        AppSharedState.sharedInstance.companies.append(company)
                    }
                    if(!AppSharedState.sharedInstance.companiesT.contains(company))
                    {
                        AppSharedState.sharedInstance.companiesT.append(company)
                    }
                } catch {
                    print("Select failed")
                }
            }
        } catch {
            print("Select failed")
        }
        
        let arrTypes = DBHandler.getDataFromTable("SELECT * FROM types")
        
        do {
            for typeItem in arrTypes! {
                do {
                    
                    let dicType = typeItem as! NSDictionary
                    
                    let type = dicType.value(forKey: "type") as! String
                    let selected = (dicType.value(forKey: "selected") as! NSString).integerValue
                    
                    if(selected == 1 && !AppSharedState.sharedInstance.types.contains(type))
                    {
                        AppSharedState.sharedInstance.types.append(type)
                    }
                    if(!AppSharedState.sharedInstance.typesT.contains(type))
                    {
                        AppSharedState.sharedInstance.typesT.append(type)
                    }
                } catch {
                    print("Select failed")
                }
            }
        } catch {
            print("Select failed")
        }
        
        let arrProducts = DBHandler.getDataFromTable("SELECT * FROM Products")
        
        do {
            for product in arrProducts! {
                do {
                    
                    let dicProduct = product as! NSDictionary
                    
                    let prodcutName = dicProduct.value(forKey: "name") as! String
                    let prodcutDesc = dicProduct.value(forKey: "description") as! String
                    let prodcutCompany = dicProduct.value(forKey: "company") as! String
                    let productType = dicProduct.value(forKey: "type") as! String
                    let productMRP = dicProduct.value(forKey: "mrp") as! String
                    let productRate = dicProduct.value(forKey: "rate") as! String
                    let productKey = dicProduct.value(forKey: "key") as! String
                    let productPacking = dicProduct.value(forKey: "packing") as! String
                    let productlut = dicProduct.value(forKey: "lut") as! NSString
                    let productScheme = dicProduct.value(forKey: "scheme") as! String
                    
                    let prod = try Product(
                        name: prodcutName,
                        company: prodcutCompany,
                        type: productType, rate: productRate, mrp: productMRP, key: productKey,packing: productPacking,desc: prodcutDesc,
                        lut: Int64(productlut.integerValue),scheme: productScheme)
                    
                    if(AppSharedState.sharedInstance.companies.contains(prod.company)
                        && AppSharedState.sharedInstance.types.contains(prod.type))
                    {
                        products.append(prod)
                        
                        AppSharedState.sharedInstance.productsDict[prod.key] = prod
                    }
                } catch {
                    print("Select failed")
                }
            }
        } catch {
            print("Select failed")
        }
        
        return products
    }
    
    func getOrders() {
        
        let arrOrders = DBHandler.getDataFromTable("SELECT * FROM orders")
        
        do {
            for order in arrOrders! {
                
                let dicOrder = order as! NSDictionary
                
                var orderDet : OrderDetail? = nil
                
                orderDet = OrderDetail()
                orderDet?.orderCase = dicOrder.value(forKey: "cases") as! String
                orderDet?.orderQty = dicOrder.value(forKey: "units") as! String
                orderDet?.remarks = dicOrder.value(forKey: "remarks") as! String
                orderDet?.lut = Int64((dicOrder.value(forKey: "lut") as! NSString).integerValue)
                orderDet?.isSelected = true
                orderDet?.product = AppSharedState.sharedInstance.productsDict[dicOrder.value(forKey: "key") as! String]
                let st : Int64 = Int64((dicOrder.value(forKey: "status") as! NSString).integerValue)
                
                if st == 0
                {
                    AppSharedState.sharedInstance.Orders.append((orderDet)!)
                }
                else
                {
                    AppSharedState.sharedInstance.OrderHistory.append((orderDet)!)
                }
                
            }
            
            UserDefaults.standard.set("\(AppSharedState.sharedInstance.Orders.count)", forKey: "OrderCount")
            UserDefaults.standard.synchronize()
            
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadHistory"), object: nil, userInfo: nil)

            
        } catch {
            print("Select failed")
        }
        
        
    }
}

