//
//  collectionViewCell.swift
//  IshwarPharma
//
//  Created by Rp on 01/04/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class collectionViewCell: UICollectionViewCell {
    
    @IBOutlet var imgView : UIImageView!
    @IBOutlet var lblName : UILabel!
    
}
