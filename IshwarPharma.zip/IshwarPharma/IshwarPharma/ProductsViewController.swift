//
//  ProductsViewController.swift
//  Ishwar Pharma
//
//  Created by Rp on 22/03/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit
import SwiftSpinner

class ProductsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate {
    
    @IBOutlet var tblView : UITableView!
    @IBOutlet weak var txtSearch: UITextField!
    
    var searchActive : Bool = false
    var products = [Product]()
    var productsOriginal = [Product]()
    var filteredProducts = [Product]()
    var strType : String = ""
    var str : String = ""
    var arrTypes = NSArray()
    var arrCompanies = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        tblView.estimatedRowHeight = 120
        tblView.rowHeight = UITableView.automaticDimension
        tblView.separatorStyle = .none
        tblView.tableFooterView = UIView()
        
        self.products.removeAll()
        self.products.append(contentsOf: AppSharedState.sharedInstance.Products)
        self.productsOriginal.removeAll()
        self.productsOriginal.append(contentsOf: AppSharedState.sharedInstance.Products)
        AppSharedState.sharedInstance.Products.removeAll()
        
        self.arrTypes = DBHandler.getDataFromTable("SELECT DISTINCT * FROM types")
        self.arrCompanies = DBHandler.getDataFromTable("SELECT DISTINCT * FROM companies")
        
        // self.loadProducts()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        if strType == "company"{
            
            var filteredArray = self.productsOriginal.filter( { (product: Product) -> Bool in
                
                return product.company.uppercased() == self.str ||  product.company ==  self.str
            })
            
            self.products = filteredArray
            self.tblView.reloadData()
            
        }
        else if strType == "type"{
            
            var filteredArray = self.productsOriginal.filter( { (product: Product) -> Bool in
                
                return product.type.uppercased() == self.str ||  product.type ==  self.str
            })
            
            self.products = filteredArray
            self.tblView.reloadData()
            
        }
        else{
            self.txtSearch.text = ""
            self.searchActive = false
            self.filteredProducts.removeAll()
            self.products = self.productsOriginal
            self.tblView.reloadData()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        self.strType = ""
    }
    
    
    func convertToDictionary(text: String) -> [String: Any]? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        searchActive = true;
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        searchActive = true;
        
    }
    
    @IBAction func changeText(textField:UITextField){
        
        self.filteredProducts.removeAll()
        
        var strMainSearch = textField.text!
        let strSplit = textField.text?.components(separatedBy: " ") as! [String]
        
        var strTempSearch : String = ""
        
        for index in 0..<strSplit.count
        {
            let str = strTempSearch.appending(strSplit[index])
            
            if str.count >= 3{
                
                let predciate = NSPredicate.init(format:"type CONTAINS [cd] %@", str)
                let filteredType = self.arrTypes.filtered(using: predciate) as! NSArray
                
                if filteredType.count > 0{
                    
                    strMainSearch =  strMainSearch.replacingOccurrences(of: str, with: "")
                    
                    if self.filteredProducts.count > 0{
                        
                        let filtered = self.filteredProducts.filter({ (text) -> Bool in
                            let tmp: NSString = text.type as NSString
                            let range = tmp.range(of: str,  options: NSString.CompareOptions.caseInsensitive)
                            return range.location != NSNotFound
                        })
                        self.filteredProducts.removeAll()
                        self.filteredProducts.append(contentsOf: filtered)
                    }
                    else{
                        
                        let filtered = products.filter({ (text) -> Bool in
                            let tmp: NSString = text.type as NSString
                            let range = tmp.range(of: str,  options: NSString.CompareOptions.caseInsensitive)
                            return range.location != NSNotFound
                        })
                        
                        self.filteredProducts.append(contentsOf: filtered)
                    }
                    
                }
                
                let predciateCompanies = NSPredicate.init(format: "company CONTAINS [cd] %@", str)
                let filteredCompanies = self.arrCompanies.filtered(using: predciateCompanies) as! NSArray
                
                if filteredCompanies.count > 0{
                    
                    strMainSearch = strMainSearch.replacingOccurrences(of: str, with: "")
                    
                    if self.filteredProducts.count > 0{
                        
                        let filtered = self.filteredProducts.filter({ (text) -> Bool in
                            let tmp: NSString = text.company as NSString
                            let range = tmp.range(of: str,  options: NSString.CompareOptions.caseInsensitive)
                            return range.location != NSNotFound
                        })
                        
                        self.filteredProducts.removeAll()
                        self.filteredProducts.append(contentsOf: filtered)
                        
                    }
                    else{
                        let filtered = products.filter({ (text) -> Bool in
                            let tmp: NSString = text.company as NSString
                            let range = tmp.range(of: str,  options: NSString.CompareOptions.caseInsensitive)
                            return range.location != NSNotFound
                        })
                        
                        self.filteredProducts.append(contentsOf: filtered)
                        
                    }
                    
                    
                }
                
            }
            
            let subString = strMainSearch.components(separatedBy: " ") as! [String]
            
            for index in 0..<subString.count
            {
                let filtered = products.filter({ (text) -> Bool in
                    let tmp: NSString = text.description as NSString
                    let range = tmp.range(of: subString[index],  options: NSString.CompareOptions.caseInsensitive)
                    
                    var range2 : NSRange!
                    
                    if index < subString.count - 1{
                        
                        range2 = tmp.range(of: subString[index+1],  options: NSString.CompareOptions.caseInsensitive)
                        
                    }
                    
                    if range2 != nil{
                        return range.location != NSNotFound && range2.location != NSNotFound
                    }
                    else{
                        return range.location != NSNotFound
                    }
                    
                })
                
                self.filteredProducts.append(contentsOf: filtered)
            }
            
            for index in 0..<subString.count
            {
                let filtered = products.filter({ (text) -> Bool in
                    let tmp: NSString = text.name as NSString
                    let range = tmp.range(of: subString[index],  options: NSString.CompareOptions.caseInsensitive)
                    
                    var range2 : NSRange!
                    
                    if index < subString.count - 1{
                        
                        range2 = tmp.range(of: subString[index+1],  options: NSString.CompareOptions.caseInsensitive)
                        
                    }
                    
                    if range2 != nil{
                        return range.location != NSNotFound && range2.location != NSNotFound
                    }
                    else{
                        return range.location != NSNotFound
                    }
                    
                })
                
                self.filteredProducts.append(contentsOf: filtered)
            }
            
            searchActive = true
            self.tblView.reloadData()
        }
        
        
        
        
        //        if(textField.text == "")
        //        {
        //            searchActive = false;
        //
        //        }
        //        else{
        //            self.filteredProducts = products.filter({ (text) -> Bool in
        //                let tmp: NSString = text.name as NSString
        //                let range = tmp.range(of: textField.text!,  options: NSString.CompareOptions.caseInsensitive)
        //                let tmpDesc: NSString = text.description as NSString
        //                let rangeDesc = tmpDesc.range(of: textField.text!,  options: NSString.CompareOptions.caseInsensitive)
        //                return range.location != NSNotFound || rangeDesc.location != NSNotFound
        //            })
        //            searchActive = true;
        //
        //        }
        
    }
    
    func loadProducts(){
        
        self.products.removeAll()
        AppSharedState.sharedInstance.Products.append(contentsOf: DataProvider.instance.getProducts())
        DataProvider.instance.getOrders()
        
        DispatchQueue.main.async {
            
            if(AppSharedState.sharedInstance.Orders.count > 0)
            {
                self.tabBarController?.tabBar.items![1].badgeValue = (AppSharedState.sharedInstance.Orders.count as NSNumber).stringValue
            }
            else{
                self.tabBarController?.tabBar.items![1].badgeValue = nil
            }
            
        }
        
        self.products.append(contentsOf: AppSharedState.sharedInstance.Products)
        
        DispatchQueue.main.async {
            self.tblView.reloadData()
        }
        
        let arrProduct = DBHandler.getDataFromTable("SELECT * FROM Products ORDER BY lut DESC LIMIT 1")
        
        if (arrProduct?.count)! > 0{
            
            DataProvider.instance.lutMax = Int64(((arrProduct?.object(at: 0) as! NSDictionary).value(forKey: "lut") as! NSString).integerValue)
        }
        
        let str = "http://onride.co.in/ishwarpharma/sync.php?lut=" + NSNumber(value:DataProvider.instance.lutMax).stringValue
        
        let urlString = URL(string:str)
        if let url = urlString {
            let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
                if error != nil {
                    
                    let alert = UIAlertController(title: "Ishwar Pharma", message: "Could not fetch products. Please check network connection", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    self.products.removeAll()
                    self.products.append(contentsOf: AppSharedState.sharedInstance.Products)
                    DispatchQueue.main.async {
                        self.tblView.reloadData()
                    }
                    return;
                } else {
                    if data != nil {
                        let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                        let dict = self.convertToDictionary(text: dataString! as String)
                        if(!(dict == nil))
                        {
                            AppSharedState.sharedInstance.Products.removeAll()
                            //DataProvider.instance.removeProducts()
                            if let array = dict!["payload"] as? NSArray {
                                if(array.count > 0)
                                {
                                    DataProvider.instance.removeProducts()
                                }
                                for case let result  in array {
                                    do {
                                        let product = try Product(json: ((result as! NSDictionary)["data"] as! NSDictionary))
                                        AppSharedState.sharedInstance.Products.append(product)
                                        
                                        let success =  DBHandler.addProduct(product.name, desc: product.description, company: product.company, type: product.type, mrp: product.mrp, rate: product.rate, key: product.key, packing: product.packing, lut: product.lut, scheme: product.scheme)
                                        
                                        if success{
                                            print("success")
                                        }
                                        else{
                                            print("Failed Product Insert")
                                        }
                                        
                                        let successCompanies = DBHandler.addCompanies(product.company, selected: 1)
                                        
                                        if successCompanies{
                                            print("success")
                                        }
                                        else{
                                            print("Failed Companies Insert")
                                        }
                                        
                                        let successType = DBHandler.addType(product.type, selected: 1)
                                        
                                        if successType{
                                            print("success")
                                        }
                                        else{
                                            print("Failed Types Insert")
                                        }
                                        
                                    }
                                    catch{}
                                }
                            }
                        }
                    }
                    self.products.removeAll()
                    self.products.append(contentsOf: AppSharedState.sharedInstance.Products)
                    AppSharedState.sharedInstance.Products.removeAll()
                    
                    DispatchQueue.main.async {
                        self.tblView.reloadData()
                    }
                }
            }
            task.resume()
        }
        //}
        //        else{
        //            self.products.append(contentsOf: AppSharedState.sharedInstance.Products)
        //            print(self.products.count)
        //            DispatchQueue.main.async {
        //                self.tableView.reloadData()
        //            }
        //        }
        let dlUrlString = URL(string: "http://onride.co.in/ishwarpharma/download.php")
        if let url = dlUrlString {
            let dltask = URLSession.shared.dataTask(with: url) { (data, response, error) in
                if error != nil {
                    print(error ?? "none")
                } else {
                    if data != nil {
                        let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                        let dict = self.convertToDictionary(text: dataString! as String)
                        if let array = dict!["payload"] as? NSArray {
                            for case let result  in array {
                                do {
                                    let dl = try DownloadDetails(json: ((result as! NSDictionary)["data"] as! NSDictionary))
                                    AppSharedState.sharedInstance.Downloads.append(dl)
                                }
                                catch{}
                            }
                        }
                    }
                }
            }
            dltask.resume()
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if(searchActive) {
            return filteredProducts.count
        }
        return products.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellproduct", for: indexPath)
        
        let view = cell.contentView.viewWithTag(1000) as UIView?
        view?.layer.shadowColor = UIColor.lightGray.cgColor
        view?.layer.shadowOffset = CGSize(width: 3, height: 3)
        view?.layer.shadowOpacity = 2
        view?.layer.shadowRadius = 3
        view?.layer.masksToBounds = false
        view?.layer.borderColor = UIColor.gray.cgColor
        view?.layer.borderWidth = 1
        
        let lblProductName = cell.contentView.viewWithTag(1001) as! UILabel
        let lblCompanyName = cell.contentView.viewWithTag(1002) as! UILabel
        let lblRate = cell.contentView.viewWithTag(1003) as! UILabel
        let lblMrp = cell.contentView.viewWithTag(1004) as! UILabel
        let lblFreeScheme = cell.contentView.viewWithTag(1005) as! UILabel
        let lblDescription = cell.contentView.viewWithTag(1006) as! UILabel
        
        //  let product = self.products[indexPath.row]
        
        var product:Product;
        
        if(searchActive){
            if(filteredProducts.count >= indexPath.row)
            {
                product = filteredProducts[indexPath.row]
            }
            else
            {
                product = products[indexPath.row];
            }
        }
        else
        {
            product = products[indexPath.row]
        }
        
        lblProductName.text = product.name + " " + product.packing
        lblCompanyName.text = product.company.uppercased()
        lblRate.text = "Rs. " + (product.rate)
        lblMrp.text = "Rs. " + (product.mrp)
        lblDescription.text = product.description
        lblFreeScheme.text = product.scheme == "" ? "N.A" : product.scheme
        
        if self.searchActive{
           
            let color = UIColor.init(red: 231.0/255.0, green: 78.0/255.0, blue: 132.0/255.0, alpha: 1.0)
            
            let attributedString = NSMutableAttributedString(attributedString: lblDescription.attributedText!)
            attributedString.setColorForAllOccuranceOfText(txtSearch.text!, with: color)
            lblDescription.attributedText = attributedString
            
            let attributedStringName = NSMutableAttributedString(attributedString: lblProductName.attributedText!)
            attributedStringName.setColorForAllOccuranceOfText(txtSearch.text!, with: color)
            lblProductName.attributedText = attributedStringName
            
            let attributedStringCompany = NSMutableAttributedString(attributedString: lblCompanyName.attributedText!)
            attributedStringCompany.setColorForAllOccuranceOfText(txtSearch.text!, with: color)
            lblCompanyName.attributedText = attributedStringCompany
        
        }
        
        cell.selectionStyle = .none
        
        return cell
    }
    
    func boldedString(with baseString: String, searchString: String, fontSize: CGFloat) -> NSAttributedString? {
        
        let attrStr = NSMutableAttributedString(string: baseString)
        let inputLength = attrStr.length
        let searchLength = searchString.characters.count
        var range = NSRange(location: 0, length: (attrStr.string as! NSString).length)
        
        while (range.location != NSNotFound) {
            range = (attrStr.string as NSString).range(of: searchString, options: [], range: range)
            if (range.location != NSNotFound) {
                attrStr.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.yellow, range: NSRange(location: range.location, length: searchLength))
                range = NSRange(location: range.location + range.length, length: inputLength - (range.location + range.length))
            }
        }
        
        return attrStr
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let addToCartVC = self.storyboard?.instantiateViewController(withIdentifier: "AddToCartViewController") as! AddToCartViewController
        
        addToCartVC.modalTransitionStyle = .crossDissolve
        
        if (UIDevice.current.systemVersion as NSString).floatValue >= 8.0
        {
            addToCartVC.modalPresentationStyle = .overCurrentContext
            addToCartVC.definesPresentationContext = true
        }
        else{
            
            addToCartVC.modalPresentationStyle = .currentContext
        }
        
        let selectedIndex = indexPath
        let globalVar = selectedIndex.row
        print("tableView prepareForSegue: " + String(globalVar))
        var product:Product;
        
        if(searchActive){
            product = self.filteredProducts[globalVar]
        }
        else
        {
            product = self.products[globalVar]
        }
        addToCartVC.product = product
        
        self.present(addToCartVC, animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        view.endEditing(true)
        let detail = segue.destination as! AddToCartViewController
        
        let selectedIndex = self.tblView.indexPath(for: sender as! UITableViewCell)
        let globalVar = selectedIndex!.row
        print("tableView prepareForSegue: " + String(globalVar))
        var product:Product;
        
        if(searchActive){
            product = self.filteredProducts[globalVar]
        }
        else
        {
            product = self.products[globalVar]
        }
        detail.product = product
        print(self.view.bounds.width)
        
        //detail.P = ""
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    
    
}

extension NSMutableAttributedString{
    func setColorForText(_ textToFind: String, with color: UIColor) {
        let range = self.mutableString.range(of: textToFind, options: .caseInsensitive)
        if range.location != NSNotFound {
            addAttribute(NSAttributedString.Key.foregroundColor, value: color, range: range)
        }
    }
    
    func setColorForAllOccuranceOfText(_ textToFind: String, with color: UIColor) {
      
        let array = textToFind.components(separatedBy: " ")
        
        for index in 0..<array.count
        {
            let strFind = array[index]
            let inputLength = self.string.count
            let searchLength = strFind.count
            var range = NSRange(location: 0, length: self.length)
            while (range.location != NSNotFound) {
                range = (self.string as NSString).range(of: strFind, options: .caseInsensitive, range: range)
                if (range.location != NSNotFound) {
                    self.addAttribute(NSAttributedString.Key.foregroundColor, value: color, range: NSRange(location: range.location, length: searchLength))
                    range = NSRange(location: range.location + range.length, length: inputLength - (range.location + range.length))
                }
            }
        }
        
       
    }
}
