//
//  ViewController.swift
//  Ishwar Pharma
//
//  Created by Rp on 22/03/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIGestureRecognizerDelegate {
    
    @IBOutlet weak var viewSettings: UIView!
    @IBOutlet weak var btnMenu: UIButton!
    @IBOutlet var viewMain: UIView!
    
    var pageMenu : CAPSPageMenu?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.navigationController?.navigationBar.isHidden = true
        self.navigationController?.navigationBar.isTranslucent = false
        
        var controllerArray : [UIViewController] = []
        
        let homeVC = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        homeVC.title = "Home"
        controllerArray.append(homeVC)
        
        let productVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductsViewController") as! ProductsViewController
        productVC.title = "Products"
        controllerArray.append(productVC)
        
        let cartVC = self.storyboard?.instantiateViewController(withIdentifier: "CartViewController")as! CartViewController
        cartVC.title = "Cart"
        controllerArray.append(cartVC)
        
        let historyVC = self.storyboard?.instantiateViewController(withIdentifier: "HistoryViewController")as! HistoryViewController
        historyVC.title = "History"
        controllerArray.append(historyVC)
        
        let notificationVC = self.storyboard?.instantiateViewController(withIdentifier: "NotificationsViewController")as! NotificationsViewController
        notificationVC.title = "Notifications"
        controllerArray.append(notificationVC)
        
        let downloadVC = self.storyboard?.instantiateViewController(withIdentifier: "DownloadsViewController")as! DownloadsViewController
        downloadVC.title = "Downloads"
        controllerArray.append(downloadVC)
        
        
        let parameters = [CAPSPageMenuOptionScrollMenuBackgroundColor:UIColor.init(red: 0.0/255.0, green: 202.0/255.0, blue: 215.0/255.0, alpha: 1.0),CAPSPageMenuOptionViewBackgroundColor:UIColor.init(red: 0.0/255.0, green: 202.0/255.0, blue: 215.0/255.0, alpha: 1),CAPSPageMenuOptionSelectionIndicatorColor:UIColor.white,CAPSPageMenuOptionBottomMenuHairlineColor:UIColor.white,CAPSPageMenuOptionMenuHeight:40,CAPSPageMenuOptionMenuItemWidthBasedOnTitleTextWidth:true,CAPSPageMenuOptionCenterMenuItems:true,CAPSPageMenuOptionMenuItemFont:UIFont.boldSystemFont(ofSize: 13),CAPSPageMenuOptionSelectedMenuItemLabelColor:UIColor.white,CAPSPageMenuOptionUnselectedMenuItemLabelColor:UIColor.white] as [String : Any]
        
        self.pageMenu = CAPSPageMenu.init(viewControllers: controllerArray, frame: CGRect(x: 0.0, y: 84.0, width: self.view.frame.width, height: self.view.frame.height-64.0), options: parameters)
        
        self.view.addSubview(self.pageMenu!.view)
        
     

        let tapGesture = UITapGestureRecognizer.init(target: self, action: #selector(tapOnView(viewMain:)))
        tapGesture.delegate = self
        tapGesture.cancelsTouchesInView = false
        viewMain.addGestureRecognizer(tapGesture)

        self.view.bringSubviewToFront(viewSettings)
    }
    
    @IBAction func clickOnMenu(btn:UIButton){
        
        viewSettings.isHidden = false
    }
    
    @IBAction func clickOnSetting(btn:UIButton){
        
        self.openSettingVC()
    }
    
    func openSettingVC()
    {
        let settingVC = self.storyboard?.instantiateViewController(withIdentifier: "SettingViewController") as! SettingViewController
        self.navigationController?.pushViewController(settingVC, animated: true)
    }
    
    @IBAction func clickONAboutUs(btn:UIButton){
        
        let aboutUsVc = self.storyboard?.instantiateViewController(withIdentifier: "AboutUsViewController") as! AboutUsViewController
        self.navigationController?.pushViewController(aboutUsVc, animated: true)
    }
    
    @objc func tapOnView(viewMain:UIView){

        viewSettings.isHidden = true
    }
    
    
}

