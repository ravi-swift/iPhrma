//
//  CartViewController.swift
//  Ishwar Pharma
//
//  Created by Rp on 22/03/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit
import SwiftSpinner

class CartViewController: UIViewController, UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,SwitchChangedDelegate {
    
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var txtRemarks: UITextView!
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
        
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }

    let cellReuseIdentifier = "cell"
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        // Initialize Tab Bar Item
        tabBarItem = UITabBarItem(title: "Cart", image:UIImage(named:"cart_20"), tag: 1)
    }
    func switchChanged() {
        self.tblView.reloadData()
        //        var total = 0.0;
        //        for order in AppSharedState.sharedInstance.Orders
        //        {
        //            if(order.isSelected)
        //            {
        //                total += order.total
        //
        //            }
        //        }
        //        let formatter = NumberFormatter()
        //        formatter.numberStyle = .decimal
        //        formatter.maximumFractionDigits = 2
        //        formatter.roundingMode = .up
        
        //let str = formatter.string(from: NSNumber(value: total))
        // self.labelTotal.text = "Total = Rs. " + str!;
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.tblView.register(UITableViewCell.self, forCellReuseIdentifier: cellReuseIdentifier)
        
        tblView.tableFooterView = UIView()
        tblView.separatorStyle = .none

        txtRemarks.placeholder = "'Special Remarks'"
    }
    
    func showTotal()
    {
        //        var total = 0.0;
        //        for order in AppSharedState.sharedInstance.Orders
        //        {
        //            if(order.isSelected)
        //            {
        //                total += order.total
        //
        //            }
        //        }
        //        let formatter = NumberFormatter()
        //        formatter.numberStyle = .decimal
        //        formatter.maximumFractionDigits = 2
        //        formatter.roundingMode = .up
        //
        //        let str = formatter.string(from: NSNumber(value: total))
        //        self.labelTotal.text = "Total = Rs. " + str!;
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //showTotal()
        self.tblView.reloadData()
        setupViewResizerOnKeyboardShown()
    }
    
    var orignalHeight = CGFloat(0);
    func setupViewResizerOnKeyboardShown() {
        //scrollView.contentOffset = .zero
        
        NotificationCenter.default.addObserver(self,selector:#selector(self.keyboardWillShowForResizing),name:UIResponder.keyboardDidShowNotification,object: nil)
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(self.keyboardWillHideForResizing),
                                               name:UIResponder.keyboardDidHideNotification,
                                               object: nil)
    }
    
    @objc func keyboardWillShowForResizing(notification: Notification) {
        guard let keyboardFrameValue = notification.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue else {
            return
        }
        let keyboardFrame = view.convert(keyboardFrameValue.cgRectValue, from: nil)
        //                self.orignalHeight = self.stackView.bounds.size.height
        //                print(self.view.bounds.origin.x)
        //                self.stackView.bounds.size.height = self.stackView.bounds.size.height-max(keyboardFrame.size.height,216 )
        //                print(self.view.bounds.origin.x)
        //scrollView.contentOffset = CGPoint(x:0, y:max(keyboardFrame.size.height,216 ))
    }
    @objc func keyboardWillHideForResizing(notification: Notification) {
        //scrollView.contentOffset = .zero
        //self.stackView.bounds.size.height = self.orignalHeight
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return AppSharedState.sharedInstance.Orders.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellIdentifier = "OrderDetailsItemTableViewCell"
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? OrderDetailsItemTableViewCell  else {
            fatalError("The dequeued cell is not an instance of MealTableViewCell.")
        }
        
        let view = cell.contentView.viewWithTag(1000) as UIView?
        view?.layer.shadowColor = UIColor.lightGray.cgColor
        view?.layer.shadowOffset = CGSize(width: 3, height: 3)
        view?.layer.shadowOpacity = 2
        view?.layer.shadowRadius = 3
        view?.layer.masksToBounds = false
        
        let product = AppSharedState.sharedInstance.Orders[indexPath.row]
        
        cell.delegate = self;
//        cell.ProdutName.textAlignment = NSTextAlignment.left
//        cell.OrderQty.textAlignment = NSTextAlignment.left
        cell.order = product
        cell.ProdutName.text = (product.product?.name)! + " " + (product.product?.packing)!
        
        //cell.SelectedSwitch.isOn = true
        if(product.orderQty != "0")
        {
            if(product.orderQty != "")
            {
                cell.OrderQty.text =  product.orderQty + " unit(s)"
                if(product.orderCase != "0")
                {
                    if(product.orderCase != "")
                    {
                        cell.OrderQty.text = cell.OrderQty.text! + " and ";
                    }
                }
            }
        }
        if(product.orderCase != "0")
        {
            if(product.orderCase != "")
            {
                cell.OrderQty.text = cell.OrderQty.text! + " " + product.orderCase;
            }
        }
        //cell.OrderQty.text = (product.product?.qty)! + " * " + product.orderQty
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 2
        formatter.roundingMode = .up
        //cell.SelectedSwitch.isOn = product.isSelected
        // _ = formatter.string(from: NSNumber(value: product.total))
        //cell.OrderQty.text = cell.OrderQty.text! + " * " + (product.product?.mrp)! + " = Rs. " + str!
        
        
        // Configure the cell...
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    @IBAction func clickOnSend(_ sender: Any) {
        view.endEditing(true)
       
        if AppSharedState.sharedInstance.Email == ""
        {
            let alert = UIAlertController(title: "Ishwar Pharma", message: "Please enter profile information", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction.init(title: "Ok", style: .default, handler: { (action) in
              
                let navigation = UIApplication.shared.keyWindow?.rootViewController as! UINavigationController
                
                let controller = navigation.viewControllers[0] as! ViewController
                controller.openSettingVC()
               
            }))
            self.present(alert, animated: true, completion: nil)
            self.tabBarController?.selectedIndex = 2
            return
        }
        
        SVProgressHUD.show(withStatus: "Sending order...")
        //SwiftSpinner.show("Sending order...")
        var bodyData = " Order from "  + AppSharedState.sharedInstance.Name + " - " +  AppSharedState.sharedInstance.Number + "\r\n" + "******************" + "\r\n"
        var count = 0
        let sentOrders = [OrderDetail]()
        
        var subjBuilder = String()
        var productBuilder = String()

        
        for case let order in AppSharedState.sharedInstance.Orders
        {
            if (order.isSelected)
            {
                productBuilder.append("<tr>")
//                isAnyChecked = true;
                subjBuilder.append("Code: " + (order.product?.name)!)
                
                productBuilder.append("<td>")
                productBuilder.append((order.product?.name)!)
                productBuilder.append("</td>")

                if order.orderQty > "0" {
                    
                    productBuilder.append("<td>")
                    productBuilder.append(order.orderQty)
                    productBuilder.append("</td>")
                    subjBuilder.append("Units: " + order.orderQty)

                } else {
                    productBuilder.append("<td>")
                    productBuilder.append("</td>")
                }
                
                if order.orderCase > "0" {
                    
                    productBuilder.append("<td>")
                    productBuilder.append(order.orderCase)
                    productBuilder.append("</td>")
                    subjBuilder.append("Cases: " + order.orderCase)
                }else{
                    productBuilder.append("<td>")
                    productBuilder.append("</td>")
                }
                
                if order.remarks.length > 0 {
                    productBuilder.append("<td>")
                    
                    
                    productBuilder.append(order.remarks)
                    productBuilder.append("</td>")
                    subjBuilder.append("Remarks: " + order.remarks)
                } else {
                    productBuilder.append("<td>")
                    productBuilder.append("</td>")
                }
                
                if order.freeScheme.length > 0 {
                    productBuilder.append("<td>")
                    productBuilder.append(order.freeScheme)
                    productBuilder.append("</td>")
                    subjBuilder.append("Free Scheme: " + order.freeScheme)
                } else {
                    productBuilder.append("<td>")
                    productBuilder.append("</td>")
                }
                
                 subjBuilder.append("******************")
//                 totalValue += order.value;
            
               
                productBuilder.append("</tr>")
                
                count = count + 1
//                sentOrders.append(order)
               
//                bodyData = bodyData + "Code: " + (order.product?.name)! + " " + (order.product?.packing)! + "\r\n"
//                if(order.orderQty != "0" )
//                {
//                    bodyData = bodyData + "Units: " + order.orderQty + "\r\n"
//                }
//                if(order.orderCase != "0")
//                {
//                    bodyData = bodyData + "Cases: " + order.orderCase + "\r\n"
//                }
//                bodyData = bodyData + "Remarks: " + order.remarks + "\r\n"
//                bodyData = bodyData + "******************" + "\r\n"
            }
        }
        if(count == 0)
        {
            let alert = UIAlertController(title: "Ishwar Pharma", message: "Please select atleast 1 order", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            DispatchQueue.main.async {
               SVProgressHUD.dismiss()
                
            }
            return;
        }
        if(self.txtRemarks.text! != "")
        {
            bodyData = bodyData + "Special Remarks = " + self.txtRemarks.text!
        }
        let remark = self.txtRemarks.text!
        var subject = "New order from " + AppSharedState.sharedInstance.Name
        let name = AppSharedState.sharedInstance.Name
        let number = AppSharedState.sharedInstance.Number
        bodyData = bodyData.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
        subject = subject.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
        let email = AppSharedState.sharedInstance.Email.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
        
        productBuilder = productBuilder.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlHostAllowed)!
        
        let urlString = URL(string: "http://onride.co.in/IshwarPharma/order.php?body=\(bodyData)&subject=\(subject)&email=\(email)&name=\(name)&phoneno=\(number)&products=\(productBuilder)&specialremark=\(remark)")
        
        let url = urlString
        let task = URLSession.shared.dataTask(with: url!) { (data, response, error) in
            if error != nil {
                let alert = UIAlertController(title: "Ishwar Pharma", message: "Order could not be sent successfully. Please check network connection", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                DispatchQueue.main.async {SVProgressHUD.dismiss()}
                return;
            } else {
                print("Sent")
                for case let order in sentOrders
                {
                    DataProvider.instance.updateOrder(order: order)
                    var i : Int = 0
                    for case let unorder in AppSharedState.sharedInstance.Orders
                    {
                        
                        if(unorder.lut == order.lut)
                        {
                            AppSharedState.sharedInstance.Orders.remove(at: i)
                        }
                        i = i+1
                    }
                }
                
                DispatchQueue.main.async {SVProgressHUD.dismiss()}
               
                let alert = UIAlertController(title: "Ishwar Pharma", message: "Order sent successfully", preferredStyle: UIAlertController.Style.alert)
               
                alert.addAction(UIAlertAction.init(title: "Ok", style: .default, handler: { (action) in
                    
                    DispatchQueue.main.async {
                        
                        self.txtRemarks.text = ""
                        AppSharedState.sharedInstance.Orders.removeAll()
                        AppSharedState.sharedInstance.OrderHistory.removeAll()
                        DataProvider.instance.getOrders()
                        self.tblView.reloadData()
                        
                        let pageMenu = self.parent as! CAPSPageMenu
                        
                        UserDefaults.standard.set("0", forKey: "OrderCount")
                        UserDefaults.standard.synchronize()
                        
                        pageMenu.setupCount()
                        
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadHistory"), object: nil, userInfo: nil)
                    }
                    
                   
                }))
                
                self.present(alert, animated: true, completion: nil)
               
                
            }
        }
        task.resume()
    }
    
}

extension String {
    var length: Int { return self.count }
}
