//
//  HistoryViewController.swift
//  Ishwar Pharma
//
//  Created by Rp on 22/03/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class HistoryViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tblView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        tblView.tableFooterView = UIView()
        tblView.separatorStyle = .none
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.reloadHistory), name: NSNotification.Name(rawValue: "reloadHistory"), object: nil)
       
    }
    
    @objc func reloadHistory()
    {
        self.tblView.reloadData()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return AppSharedState.sharedInstance.OrderHistory.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellhistory", for: indexPath) as! OrderHistoryTableViewCell
        
        let view = cell.contentView.viewWithTag(1000) as UIView?
        view?.layer.shadowColor = UIColor.lightGray.cgColor
        view?.layer.shadowOffset = CGSize(width: 3, height: 3)
        view?.layer.shadowOpacity = 2
        view?.layer.shadowRadius = 3
        view?.layer.masksToBounds = false
        
        let orderHistory = AppSharedState.sharedInstance.OrderHistory[indexPath.row];
       
        cell.qtyDetails.text = "";
        cell.orderDetails.textAlignment = NSTextAlignment.left
        cell.qtyDetails.textAlignment = NSTextAlignment.left
       
        if(orderHistory.orderQty != "0") && (orderHistory.orderQty != "")
        {
            cell.qtyDetails.text =  orderHistory.orderQty + " unit(s)"
            if(orderHistory.orderCase != "0") && (orderHistory.orderCase != "")
            {
                cell.qtyDetails.text = cell.qtyDetails.text! + " and ";
            }
            else{
                cell.qtyDetails.text = cell.qtyDetails.text! + "";
            }
            
        }
        cell.orderDetails.text = (orderHistory.product?.name)! + " " + (orderHistory.product?.packing)!
        if(orderHistory.orderCase != "0") && (orderHistory.orderCase != "")
        {
            cell.qtyDetails.text = cell.qtyDetails.text! + " " + orderHistory.orderCase + " case(s)" ;
        }
      
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
}
