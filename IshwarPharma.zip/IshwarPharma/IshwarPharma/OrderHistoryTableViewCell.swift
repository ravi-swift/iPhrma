//
//  OrderHistoryTableViewCell.swift
//  Ishwar Pharma
//
//  Created by Amarjeet Lokhande on 15/01/18.
//  Copyright © 2018 anonimous. All rights reserved.
//

import UIKit

class OrderHistoryTableViewCell: UITableViewCell {

    @IBOutlet var qtyDetails: UILabel!
    @IBOutlet var orderDetails: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
