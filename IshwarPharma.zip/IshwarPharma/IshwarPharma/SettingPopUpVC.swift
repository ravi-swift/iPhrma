//
//  SettingPopUpV.swift
//  Ishwar Pharma
//
//  Created by Rp on 25/03/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

protocol didFinishOk {
    
    func didFinishWithOk()
}

class SettingPopUpVC: UIViewController {
    
    @IBOutlet weak var lblDisplayName: UILabel!
    @IBOutlet weak var txtDisplayName: UITextField!
    
    var viewStatus = NSInteger()
    
    var delegate : didFinishOk!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        if viewStatus == 0{
            
            lblDisplayName.text = "Display Name"
            txtDisplayName.placeholder = "Display Name"
            
        }else if viewStatus == 1{
            
            lblDisplayName.text = "Email"
            txtDisplayName.placeholder = ""
            
        }else if viewStatus == 2{
            
            lblDisplayName.text = "Phone No"
            txtDisplayName.placeholder = ""
            txtDisplayName.keyboardType = .phonePad
        }
    }
    
    @IBAction func clickOnOk(_ sender: Any) {
        
        if viewStatus == 0{
            
            AppSharedState.sharedInstance.Name = txtDisplayName.text!
            
        }else if viewStatus == 1{
            AppSharedState.sharedInstance.Email = txtDisplayName.text!
            
        }else if viewStatus == 2{
            AppSharedState.sharedInstance.Number = txtDisplayName.text!
        }
      
        AppSharedState.sharedInstance.storeProfileData()
        delegate.didFinishWithOk()
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func clickOnCancle(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)
    }
    
}
