//
//  AppDelegate.swift
//  IshwarPharma
//
//  Created by Rp on 26/03/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var currentIndex : NSInteger = 0

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        IQKeyboardManager.shared.enable = true
        
        if (UserDefaults.standard.object(forKey: "isFirstTimeInstall") == nil)
        {
            DBHandler.deleteData("DELETE FROM Products")
            DBHandler.deleteData("DELETE FROM companies")
            DBHandler.deleteData("DELETE FROM types")
            DBHandler.deleteData("DELETE FROM orders")
            
            UserDefaults.standard.set(true, forKey: "isFirstTimeInstall")
            UserDefaults.standard.synchronize()
        }
        
        AppSharedState.sharedInstance.getProfileData()

        self.loadAllProducts()
        
        return true
    }
    
    func loadAllProducts()
    {
        SVProgressHUD.show(withStatus: "Syncing products.Wait for a moment...")
        
        AppSharedState.sharedInstance.Products.append(contentsOf: DataProvider.instance.getProducts())
        DataProvider.instance.getOrders()
        
        DispatchQueue.main.async {
            
            if(AppSharedState.sharedInstance.Orders.count > 0)
            {
                //self.tabBarController?.tabBar.items![1].badgeValue = (AppSharedState.sharedInstance.Orders.count as NSNumber).stringValue
            }
            else{
               // self.tabBarController?.tabBar.items![1].badgeValue = nil
            }
            
        }
        
        let arrProduct = DBHandler.getDataFromTable("SELECT * FROM Products ORDER BY lut DESC LIMIT 1")
        
        if (arrProduct?.count)! > 0{
            
            DataProvider.instance.lutMax = Int64(((arrProduct?.object(at: 0) as! NSDictionary).value(forKey: "lut") as! NSString).integerValue)
        }
        
        let str = "http://onride.co.in/ishwarpharma/sync.php?lut=" + NSNumber(value:DataProvider.instance.lutMax).stringValue
        
        let urlString = URL(string:str)
        if let url = urlString {
            let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
                
                DispatchQueue.main.async {
                    
                    SVProgressHUD.dismiss()
                }
                
                if error != nil {
                    
                    let alert = UIAlertController(title: "Ishwar Pharma", message: "Could not fetch products. Please check network connection", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                    self.window?.rootViewController!.present(alert, animated: true, completion: nil)
                    return
                } else {
                    if data != nil {
                        let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                        let dict = self.convertToDictionary(text: dataString! as String)
                        if(!(dict == nil))
                        {
                            AppSharedState.sharedInstance.Products.removeAll()
                            //DataProvider.instance.removeProducts()
                            if let array = dict!["payload"] as? NSArray {
                                if(array.count > 0)
                                {
                                    DataProvider.instance.removeProducts()
                                }
                               
                                self.currentIndex = 0
                                self.addProduct(index: self.currentIndex, array: array)
                            }
                        }
                    }
                    
                  
                }
            }
            task.resume()
            
        }
    }
    
    func convertToDictionary(text: String) -> [String: Any]? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }
    
    func addProduct(index:NSInteger,array:NSArray)
    {
        let result = array.object(at: index)
        
        do{
        let product = try Product(json: ((result as! NSDictionary)["data"] as! NSDictionary))
        AppSharedState.sharedInstance.Products.append(product)
        
        let success =  DBHandler.addProduct(product.name, desc: product.description, company: product.company, type: product.type, mrp: product.mrp, rate: product.rate, key: product.key, packing: product.packing, lut: product.lut, scheme: product.scheme)
        
        if success{
            print("success")
        }
        else{
            print("Failed Product Insert")
        }
        
        let successCompanies = DBHandler.addCompanies(product.company, selected: 1)
        
        if successCompanies{
            print("success")
        }
        else{
            print("Failed Companies Insert")
        }
        
        let successType = DBHandler.addType(product.type, selected: 1)
        
        if successType{
            print("success")
        }
        else{
            print("Failed Types Insert")
        }
        }
        catch{
            
        }
        self.currentIndex = self.currentIndex + 1
       
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.init(uptimeNanoseconds: 0)) {
            
            if self.currentIndex < array.count{
                 self.addProduct(index: self.currentIndex, array: array)
            }
            else{
               
            }
            
        }

    }
    
    @objc func setupProduct(array:NSArray)
    {
        self.addProduct(index: self.currentIndex, array: array)
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}

