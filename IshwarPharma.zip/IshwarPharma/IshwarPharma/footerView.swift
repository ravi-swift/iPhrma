//
//  footerView.swift
//  IshwarPharma
//
//  Created by Rp on 01/04/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class footerView: UIView {

    @IBOutlet var collectionView : UICollectionView!

}
