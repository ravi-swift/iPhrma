//
//  Product.swift
//  Ishwar Pharma
//
//  Created by Admin on 08/07/1939 Saka.
//  Copyright © 1939 Saka anonimous. All rights reserved.
//

import UIKit
class Product {
    
    init(name:String,company:String,type:String,rate:String,mrp:String,key:String,packing:String,desc:String,lut:Int64,scheme:String) throws {
        self.name = name.uppercased()
        self.company = company.capitalized
        self.type = type.capitalized

        self.rate = rate
        self.mrp = mrp

        self.key = key
        self.lut = NSNumber(value: lut).stringValue
        self.packing = packing
        //self.gift = "";// gift.capitalized
        self.description = desc.capitalized
        
        self.scheme = scheme
        
        
    }
    //MARK: Properties
    init(json: NSDictionary) throws {
        // Extract name
        guard let codeJson = json["code"] as? String else {
           fatalError("name")
            //return nil
        }
        guard let keyJson = json["key"] as? String else {
            fatalError("name")
            //return nil
        }
        // Extract and validate coordinates
        guard let companyJson = json["company"] as? String else {
        fatalError("coordinates")
        }
        
        
        
        // Extract and validate meals
        guard let typeJson = json["type"] as? String else {
            fatalError("meals")
       }
        guard let descriptionJson = json["description"] as? String else {
            fatalError("meals")
        }
        guard let mrpJson = json["mrp"] as? String else {
            fatalError("meals")
        }
        guard let rateJson = json["rate"] as? String else {
            fatalError("meals")
        }
//        guard let qtyJson = json["qty"] as? String else {
//            fatalError("meals")
//        }
//        guard let giftJson = json["gift"] as? String else {
//            fatalError("meals")
//        }
        guard let schemeJson = json["scheme"] as? String else {
            fatalError("meals")
        }
//        guard let shipperJson = json["shipper"] as? String else {
//            fatalError("meals")
//        }
        guard let packingJson = json["packing"] as? String else {
            fatalError("meals")
        }
        guard let lutJson = json["lut"] as? String else {
            fatalError("meals")
        }
    
        
        // Initialize properties
        self.name = codeJson.uppercased()
        self.company = companyJson.capitalized
        self.type = typeJson.capitalized
        //self.shipper = shipperJson
        self.rate = rateJson
        self.mrp = mrpJson
        self.scheme = schemeJson.capitalized
        //self.qty = qtyJson
        self.lut = lutJson
        self.packing = packingJson
        //self.gift = giftJson.capitalized
        self.key = keyJson
        self.description = descriptionJson.capitalized
        
    }
   
    var name: String
    var company: String
    var type: String
    var description: String
    var mrp: String
    //var qty: String
    var rate: String
    //var gift: String
    var scheme: String
    //var shipper: String
    var packing: String
    var key: String
    var lut: String
    func camelCaseString(source: String) -> String {
        return source.capitalized
    }
}
